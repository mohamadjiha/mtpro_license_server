
from flask import Flask, request, jsonify

app = Flask(__name__)

# قاعدة بيانات بسيطة (قابلة للربط لاحقاً بـ Google Sheets)
VALID_KEYS = ["MTPro_Secret_2025", "FAKE123", "TEST2025"]

@app.route("/check", methods=["GET"])
def check_license():
    key = request.args.get("key")
    token = request.args.get("token")

    if not key or not token:
        return jsonify({"status": "error", "message": "missing parameters"}), 400

    if key in VALID_KEYS and token == "MTPro_Secret_2025":
        return jsonify({"status": "valid"})
    else:
        return jsonify({"status": "invalid"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
